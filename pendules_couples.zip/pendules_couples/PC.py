import numpy as np
import matplotlib.pyplot as plt
from objets import MethNumInt, AnimObj


class PenCpl(MethNumInt, AnimObj):
    def __init__(self,
                 N=31, K=64, J=1,
                 T=1000, Tdeb=1, interval=10, dt=0.001, y0=np.zeros(62),
                 meth="rk4",
                 ):
        self.N, self.K, self.J = N, K, J
        self.T, self.Tdeb, self.interval, self.dt, self.y0 =\
            T, Tdeb, interval, dt, y0
        self.methode_int = getattr(self, meth)

    def F(self, t, Y):
        N, J, K = self.N, self.J, self.K
        Yp = np.zeros(len(Y))
        Yp[0:N] = Y[N:2*N]
        Yp[N:2*N] = (K/J)*np.concatenate((
            [-2*Y[0]+Y[1]],
            -2*Y[1:N-1]+Y[0:N-2]+Y[2:N],
            [-2*Y[N-1]+Y[N-2]]))
        return Yp

    def init_graph(self):
        N, J, K = self.N, self.J, self.K
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d', aspect='equal', autoscale_on=False,
                             xlim=(-1, 1), ylim=(-1, 1), zlim=(-1, 1))
        ax.grid()
        ax.set_title(f'N={N:.2f}, J={J:.2f}, K={K:.2f}')
        ax.plot([0, 0], [0, 0], [-1, 1], 'or-', lw=2)
        self.listegraph = []
        for n in range(N):
            h, = ax.plot([], [], [], 'ob-', lw=2)
            self.listegraph.append(h)
        h = ax.text(-1, -1, 0, [], backgroundcolor='y', fontweight='bold')
        self.listegraph.append(h)
        h, = ax.plot([], [], [], 'g--')
        self.listegraph.append(h)
        h, = ax.plot([], [], [], 'g--')
        self.listegraph.append(h)
        return fig

    def graph(self, yt, t):
        thetas = yt[0:self.N]
        X = 0.5*np.cos(thetas)
        Y = 0.5*np.sin(thetas)
        Z = -1+2*np.arange(1, self.N+1)/(self.N+1)
        for n in range(self.N):
            self.listegraph[n].set_data_3d(
                [-X[n], X[n]], [-Y[n], Y[n]], [Z[n], Z[n]])
        self.listegraph[self.N].set_text(f't={t:.2f}')
        self.listegraph[self.N+1].set_data_3d(X, Y, Z)
        self.listegraph[self.N+2].set_data_3d(-X, -Y, Z)
        return self.listegraph
