import numpy as np
import matplotlib.pyplot as plt
import time
from matplotlib.animation import FuncAnimation


class MethNumInt:
    def rk2(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h, yprec+h*k1)
            y[n, :] = yprec+(h/2)*(k1+k2)
        return t, y

    def rk4(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        k3 = np.copy(k1)
        k4 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h/2, yprec+(h/2)*k1)
            k3[:] = f(tprec+h/2, yprec+(h/2)*k2)
            k4[:] = f(tprec+h, yprec+h*k3)
            y[n, :] = yprec+(h/6)*(k1+2*k2+2*k3+k4)
        return t, y


class AnimObj():
    def animate(self, n):
        if n == self._Ndeb:
            self._t0 = time.time()
        if n >= self._Ndeb:
            t = time.time()
            if (t-self._t0) <= self.T:
                self._nt = np.floor((t-self._t0)/self.dt)
            else:
                self._nt = np.floor(self.T/self.dt)
            if self._nt > self._nt_prec:
                _, y = self.methode_int(self.F, np.arange(
                    self._nt_prec, self._nt+1)*self.dt, self._yt)
                self._yt = y[-1]
                self._nt_prec = self._nt
        self.graph(self._nt*self.dt, self._yt)
        return self.listegraph

    def anim(self):
        self._N = int(np.fix(1000*(self.T+self.Tdeb)/self.interval))
        self._Ndeb = int(np.fix(1000*self.Tdeb/self.interval))
        self._nt = 0
        self._nt_prec = 0
        self._t0 = 0
        self._yt = self.y0
        self.init_graph()

        animobj = FuncAnimation(self.fig, self.animate, frames=self._N,
                                interval=self.interval, blit=True, repeat=False)

        plt.show()
