import numpy as np
import matplotlib.pyplot as plt


def matA(N=31, K=64, J=1):
    A = np.zeros((2*N, 2*N))
    A[0:N, N:2*N] = np.eye(N)
    for n in range(1, N-1):
        A[N+n, n] = -2*K/J
        A[N+n, n-1] = K/J
        A[N+n, n+1] = K/J
    A[N, 0] = -2*K/J
    A[N, 1] = K/J
    A[2*N-1, N-1] = -2*K/J
    A[2*N-1, N-2] = K/J
    return A


def cond_init(N=31, K=64, J=1, G=1, n_select=0, trace=False):
    A = matA(N, K, J)
    eigenvalues, eigenvectors = np.linalg.eig(A)
    index = np.argsort(np.abs(eigenvalues))
    eigenvalues = eigenvalues[index]
    eigenvectors = eigenvectors[:, index]
    omega_select = np.abs(eigenvalues[n_select])
    y0 = np.real(G*eigenvectors[:, n_select])

    if trace == True:
        plt.figure()
        plt.plot(np.abs(eigenvalues), 'ob')
        plt.plot(n_select, omega_select, 'or', label='mode sélectionné')
        plt.title('Pulsations propres')
        plt.xlabel('index')
        plt.ylabel('rd/s')
        plt.grid('on')
        plt.legend()
        plt.figure()
        plt.plot(2*np.pi/np.abs(eigenvalues), 'ob')
        plt.plot(n_select, 2*np.pi/omega_select, 'or',
                label=f'mode sélectionné (T={2*np.pi/omega_select:.2f} s)')
        plt.title('Périodes propres')
        plt.xlabel('index')
        plt.ylabel('s')
        plt.grid('on')
        plt.legend()

        plt.figure()
        plt.plot(y0[0:N], 'ob', label='positions (rd)')
        plt.plot(y0[N:2*N], 'og', label='vitesses (rd/s)')
        plt.title('Condition initiale')
        plt.xlabel('index')
        plt.grid('on')
        plt.legend()

        plt.show()

    return y0
